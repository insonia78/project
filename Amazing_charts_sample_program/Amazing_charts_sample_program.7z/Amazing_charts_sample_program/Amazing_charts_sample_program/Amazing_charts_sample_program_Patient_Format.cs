﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Amazing_charts_sample_program
{
    public interface Amazing_charts_sample_program_Patient_Format
    {
        string FirstName { get; set; }
        string LastName { get; set; }
        string DateOfBirth { get; set; }
        string PhoneNumber { get; set; }
        string Age { get; set; }

    }
}
