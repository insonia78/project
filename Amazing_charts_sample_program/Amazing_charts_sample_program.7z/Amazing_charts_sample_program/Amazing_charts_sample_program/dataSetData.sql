USE [Amazing_charts_sample_program]
GO

INSERT INTO [dbo].[credentials]
           ([first_name]
           ,[last_name]
           ,[date_of_birth]
           ,[phone])
     VALUES
           (<first_name, varchar(max),>
           ,<last_name, varchar(max),>
           ,<date_of_birth, varchar(max),>
           ,<phone, varchar(max),>)
GO

