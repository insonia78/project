﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VAIA_Basic_programing_test
{
    public partial class Dialog : Form
    {
        private HelperFunction helper;

        public delegate void RaiseListBox(object source, EventArgs args);

        public event RaiseListBox raiseListBox;
        public Dialog(ref HelperFunction _helper)
        {
            this.helper = _helper;
           InitializeComponent();
        }

        public void ok_button_Click(object sender, EventArgs e)
        {
            if (this.textBoxData.Text != "")
            {
                this.helper.TextBoxValue = this.textBoxData.Text;
                this.Close();
                OnRaiseListBox();
            }
            else
                MessageBox.Show("Empty value not allowed!");
        }

        public void cancel_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        protected virtual void OnRaiseListBox()
        {
            if (raiseListBox != null)
                raiseListBox(this, EventArgs.Empty);
        }
        
    }
}
