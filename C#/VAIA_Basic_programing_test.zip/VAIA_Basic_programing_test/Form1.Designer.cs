﻿namespace VAIA_Basic_programing_test
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.hello_world_button = new System.Windows.Forms.Button();
            this.populate_list_box_button = new System.Windows.Forms.Button();
            this.dialog_button = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.listBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // hello_world_button
            // 
            this.hello_world_button.Location = new System.Drawing.Point(113, 79);
            this.hello_world_button.Name = "hello_world_button";
            this.hello_world_button.Size = new System.Drawing.Size(105, 70);
            this.hello_world_button.TabIndex = 0;
            this.hello_world_button.Text = "Hello World!";
            this.hello_world_button.UseVisualStyleBackColor = true;
            this.hello_world_button.Click += new System.EventHandler(this.hello_world_button_Click);
            // 
            // populate_list_box_button
            // 
            this.populate_list_box_button.Location = new System.Drawing.Point(113, 177);
            this.populate_list_box_button.Name = "populate_list_box_button";
            this.populate_list_box_button.Size = new System.Drawing.Size(107, 70);
            this.populate_list_box_button.TabIndex = 1;
            this.populate_list_box_button.Text = "Populate ListBox!";
            this.populate_list_box_button.UseVisualStyleBackColor = true;
            this.populate_list_box_button.Click += new System.EventHandler(this.populate_list_box_button_Click);
            // 
            // dialog_button
            // 
            this.dialog_button.Location = new System.Drawing.Point(419, 79);
            this.dialog_button.Name = "dialog_button";
            this.dialog_button.Size = new System.Drawing.Size(107, 70);
            this.dialog_button.TabIndex = 2;
            this.dialog_button.Text = "Dialog!";
            this.dialog_button.UseVisualStyleBackColor = true;
            this.dialog_button.Click += new System.EventHandler(this.dialog_button_Click);
            // 
            // exit_button
            // 
            this.exit_button.Location = new System.Drawing.Point(419, 177);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(107, 69);
            this.exit_button.TabIndex = 3;
            this.exit_button.Text = "Exit!";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // listBox
            // 
            this.listBox.FormattingEnabled = true;
            this.listBox.Location = new System.Drawing.Point(253, 177);
            this.listBox.Name = "listBox";
            this.listBox.Size = new System.Drawing.Size(127, 69);
            this.listBox.TabIndex = 4;
            this.listBox.SelectedIndexChanged += new System.EventHandler(this.listBox_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox);
            this.Controls.Add(this.exit_button);
            this.Controls.Add(this.dialog_button);
            this.Controls.Add(this.populate_list_box_button);
            this.Controls.Add(this.hello_world_button);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button hello_world_button;
        private System.Windows.Forms.Button populate_list_box_button;
        private System.Windows.Forms.Button dialog_button;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.ListBox listBox;
    }
}

