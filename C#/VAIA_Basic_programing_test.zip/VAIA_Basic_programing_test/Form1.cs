﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VAIA_Basic_programing_test
{
    public partial class Form1 : Form
    {        
        HelperFunction helper;
        public Form1()
        {
            helper = new HelperFunction();
            InitializeComponent();
            //setting the list box dinamically 
            
        }

        private void hello_world_button_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello World!");
        }

        private void populate_list_box_button_Click(object sender, EventArgs e)
        {
            this.listBox.Items.Clear();
            var rand = new Random();
            var seed = rand.Next(1, 1000);
            var rand1 = new Random(seed);

            for (int i = 1; i <= 1000; i++)
            {
                this.listBox.Items.Add(rand1.Next(0, 10000));
            }
        }
         

        private void dialog_button_Click(object sender, EventArgs e)
        {
            var dialog = new Dialog(ref helper);
            dialog.raiseListBox += listBox_SelectedIndexChanged;
            dialog.ShowDialog();            
        }        
        private void exit_button_Click(object sender, EventArgs ev)
        {
            try
            {
                string fileName = @"c:\output.txt";

                if (!File.Exists(fileName))
                {
                    // Create a file to write to.
                    using (StreamWriter sw = File.CreateText(fileName))
                    {
                        sw.WriteLine("This is a test!");
                        sw.Flush();
                        sw.Close();

                    }
                }
                else
                {
                    using (StreamWriter sw = File.AppendText(fileName))
                    {
                        sw.WriteLine("This is a test!");
                        sw.Flush();
                        sw.Close();
                    }
                }
                Application.Exit();
            }
            catch (Exception e)
            {
                MessageBox.Show("Exception: " + e.Message);
            }
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.listBox.Items.Clear();
            this.listBox.Items.Add(this.helper.TextBoxValue);
        }
    }
}
