﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VAIA_Basic_programing_test
{
    public class HelperFunction
    {
        public  string TextBoxValue { get; set; }
    }
}
