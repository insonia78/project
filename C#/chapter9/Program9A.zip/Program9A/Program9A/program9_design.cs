﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program9

{
    public partial class program9_design : Form
    {
                             
        public program9_design()
        {
            InitializeComponent();
             
        }

        private void first_number_TextChanged(object sender, EventArgs e)
        {

        }

        private void second_number_TextChanged(object sender, EventArgs e)
        {

        }

        private void total_TextChanged(object sender, EventArgs e)
        {

        }
       
       
    }
}
