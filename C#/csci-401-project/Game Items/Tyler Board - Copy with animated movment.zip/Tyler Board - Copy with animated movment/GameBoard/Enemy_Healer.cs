﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace GameBoard
{
    class Enemy_Healer : Enemy
    {
        public Enemy_Healer()
        {
            characterPicture = new BitmapImage(new Uri("Cook.png", UriKind.Relative));
        }

        public Enemy_Healer(int r, int c, int charSpeed) : base(r, c, charSpeed)
        {
            characterPicture = new BitmapImage(new Uri("Cook.png", UriKind.Relative));
        }
    }
}
