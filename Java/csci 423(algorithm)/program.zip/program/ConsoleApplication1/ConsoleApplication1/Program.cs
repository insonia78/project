﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gcd
{
    public class Gcd
    {
        public Gcd(int n)
        {
            int Maxcnt = 0,
            Maxgcd = 0,
            MaxZ = 0,
            grcd = 0,
            Maxj = 0;
            int i = 0,y = 0;
            int remaindor = 0;
            int numerator = 0;
            int denominator = 0;
            


            for (int z = 2; z <= n; z++)
            {
                numerator = z;
                //numerator2 = z;
                for (int j = z + 1; j <= n; j++)
                {
                     denominator = j;

                     i = 0;
                    while (denominator != 0)
                    {
                       // int division = numerator / denominator;   
                        remaindor = numerator % denominator;
                        numerator = denominator;
                        denominator = remaindor;
                        i++;
                    }
                    denominator = j;
                    grcd = numerator;
                    if (i > Maxcnt)
                    {
                        Maxcnt = i;
                        Maxgcd = grcd;
                        MaxZ = z;
                        Maxj = j;
                        //numerator1 = numerator2;
                        //denominator1 = denominator;
                        
  
                    }
                 
                }
            }
        /*    if (numerator > remaindor1)
            {
                i = y; 
                remaindor = remaindor1;
                numerator2 = numerator1;
                denominator = denominator1;
            }*/
            Console.WriteLine("For N ={0}\n The GCD of {1} and {2}= {3} and it took {4} divisions",n, MaxZ,Maxj,Maxgcd,Maxcnt);

            
        }
        static void Main(string[] args)
        {

            new Gcd(10);
            /*new Gcd(20);
            new Gcd(50);
            new Gcd(100);
            new Gcd(1000);
            //new Gcd(55,89);
            //new Gcd(610, 987);*/
            Console.Read();
        }
    }
}
