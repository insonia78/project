
/**
 * Write a description of class Prova here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Prova
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        String river = "hamburger";
       
        System.out.println(river.substring(4,8));
    }
}