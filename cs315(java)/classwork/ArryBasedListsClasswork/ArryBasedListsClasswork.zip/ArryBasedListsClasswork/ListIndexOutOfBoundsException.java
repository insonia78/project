public class ListIndexOutOfBoundsException
            extends IndexOutOfBoundsException {
  public ListIndexOutOfBoundsException(String s) {
          super(s);
          System.out.println("In Exception");
  }  // end constructor
}  // end ListIndexOutOfBoundsException
