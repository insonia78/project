/**
 * SortingAndSearching demonstrates sorting and searching on an array 
 * of objects.
 *
 * @author Dr. Chase
 * @author Dr. Lewis
 * @version 1.0, 8/18/08 */

public class SortingAndSearching 
{
   

   /**
    * Sorts the specified array of objects using the merge sort
    * algorithm.
    *
    * @param data  the array to be sorted
    * @param min   the integer representation of the minimum value 
    * @param max   the integer representation of the maximum value
    */
   public static <T extends Comparable<? super T>> void mergeSort (T[] data, int min, int max)
   {
      T[] temp;
      int index1, left, right;

      /** return on list of length one */
      if (min==max)
         return; 

      /** find the length and the midpoint of the list */
      int size = max - min + 1;
      int pivot = (min + max) / 2;
      temp = (T[])(new Comparable[size]);
      
      mergeSort(data, min, pivot); // sort left half of list
      mergeSort(data, pivot + 1, max); // sort right half of list

      /** copy sorted data into workspace */
      for (index1 = 0; index1 < size; index1++)
         temp[index1] = data[min + index1];
      
      /** merge the two sorted lists */
      left = 0;
      right = pivot - min + 1;
      for (index1 = 0; index1 < size; index1++)
      {
         if (right <= max - min)
            if (left <= pivot - min)
               if (temp[left].compareTo(temp[right]) > 0)
                  data[index1 + min] = temp[right++];
               
               else
                  data[index1 + min] = temp[left++];
            else
               data[index1 + min] = temp[right++];
         else
            data[index1 + min] = temp[left++];
      }
   }

   public static <T extends Comparable<? super T>> void PbubbleSort(T[] theArray, int n) {
// ---------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray is an array of n items.
// Postcondition: theArray is sorted into ascending
// order.  From Prichard&Carrano
// ---------------------------------------------------
  boolean sorted = false;  // false when swaps occur

  for (int pass = 1; (pass < n) && !sorted; ++pass) {
    // Invariant: theArray[n+1-pass..n-1] is sorted
    //            and > theArray[0..n-pass]
    sorted = true;  // assume sorted
    for (int index = 0; index < n-pass; ++index) {
      // Invariant: theArray[0..index-1] <= theArray[index]
      int nextIndex = index + 1;
      if (theArray[index].compareTo(theArray[nextIndex]) > 0) {
        // exchange items
        T temp = theArray[index];
        theArray[index] = theArray[nextIndex];
        theArray[nextIndex] = temp;
        sorted = false;  // signal exchange
      }  // end if
    }  // end for

    // Assertion: theArray[0..n-pass-1] < theArray[n-pass]
  }  // end for
}  // end bubbleSort
   
  public static <T extends Comparable<? super T>> void PinsertionSort(T[] theArray, int n) {
// ---------------------------------------------------
// Sorts the items in an array into ascending order.
// Precondition: theArray is an array of n items.
// Postcondition: theArray is sorted into ascending
// order. FROM PRITCHARD & CARRANO
// ---------------------------------------------------
  // unsorted = first index of the unsorted region,
  // loc = index of insertion in the sorted region,
  // nextItem = next item in the unsorted region

  // initially, sorted region is theArray[0],
  //          unsorted region is theArray[1..n-1];
  // in general, sorted region is theArray[0..unsorted-1],
  //          unsorted region is theArray[unsorted..n-1]

  for (int unsorted = 1; unsorted < n; ++unsorted) {
    // Invariant: theArray[0..unsorted-1] is sorted

    // find the right position (loc) in
    // theArray[0..unsorted] for theArray[unsorted],
    // which is the first item in the unsorted
    // region; shift, if necessary, to make room
    T nextItem = theArray[unsorted];
    int loc = unsorted;

    while ((loc > 0) &&
           (theArray[loc-1].compareTo(nextItem) > 0)) {
      // shift theArray[loc-1] to the right
      theArray[loc] = theArray[loc-1];
      loc--;
    }  // end while
    // Assertion: theArray[loc] is where nextItem belongs
    // insert nextItem into sorted region
    theArray[loc] = nextItem;
  }  // end for
}  // end insertionSort 
   
  
  

   
   
   public static <T extends Comparable<? super T>> void selectionSort (T[] data)
   {
      int min;
      T temp;
      
      for (int index = 0; index < data.length-1; index++)
      {
         min = index;
         for (int scan = index+1; scan < data.length; scan++)
            if (data[scan].compareTo(data[min])<0)
               min = scan;

         /** Swap the values */
         temp = data[min];
         data[min] = data[index];
         data[index] = temp;
      }
   }

  
   
}

