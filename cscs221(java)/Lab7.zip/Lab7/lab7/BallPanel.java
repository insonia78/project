
/**
 *: BallPanel.java
 * Creates the panel to be placed inside the BallApp window.
 * * 
 */
public class BallPanel extends javax.swing.JPanel implements Mover {
    private final int INIT_X = 75; // attributes
    private final int INIT_Y = 75;
    private final int DIAMETER = 60;
    private final int INTERVAL = 35;
    private BouncingBall _ball; // components
    private MoveTimer _timer;
    private BouncingBall _ball2;

    public BallPanel () {
	super();
	_ball = new BouncingBall (java.awt.Color.red, this);
	_ball2 = new BouncingBall (java.awt.Color.black, this);
	_timer = new MoveTimer(INTERVAL, this);
	this.setBackground(java.awt.Color.white);
	_ball.setLocation(INIT_X, INIT_Y);
	_ball.setSize(DIAMETER, DIAMETER);
	_ball2.setLocation(INIT_X - 20, INIT_Y - 20);
	_ball2.setSize(DIAMETER - 20, DIAMETER - 20);
	_timer.start();
    }

    public void move() {
	_ball.move();
	_ball2.move();
	this.repaint();
    }

    public void paintComponent (java.awt.Graphics aBrush) {
	super.paintComponent(aBrush);
	java.awt.Graphics2D betterBrush = 
	    (java.awt.Graphics2D) aBrush;
	_ball.fill(betterBrush);
	_ball2.fill(betterBrush);
    }
}

 
