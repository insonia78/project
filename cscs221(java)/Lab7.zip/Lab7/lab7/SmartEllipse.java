
/**
 * SmartEllipse.java
 * Extends Java's Ellipse2D.Double class, adding the capabilities 
 * to set location, and size, and to display itself on a panel.
 */
public class SmartEllipse extends java.awt.geom.Ellipse2D.Double {
    private java.awt.Color _borderColor, _fillColor; // attributes

    public SmartEllipse(java.awt.Color aColor){
        super(); 
	_borderColor = aColor;
	_fillColor = aColor; // solid color to start
	    }
 
     

    // more readable versions of methods provided by Java
    public void setLocation (double x, double y) {
	this.setFrame (x, y, this.getWidth(), 
		       this.getHeight());
    }
    public void setSize (int aWidth, int aHeight) {
	this.setFrame(this.getX(), this.getY(), 
		      aWidth, aHeight);
    }
 

    public void fill (java.awt.Graphics2D aBetterBrush){
	java.awt.Color savedColor = aBetterBrush.getColor();
	aBetterBrush.setColor(_fillColor);
	aBetterBrush.fill(this); // paint a solid ellipse
	aBetterBrush.setColor(savedColor);
    }
    
 
}
