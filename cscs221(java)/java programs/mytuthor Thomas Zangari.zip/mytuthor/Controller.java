
/**
 * cs201: Lab 3 geometryTutor: Thomas Zangari.
 * This is the Controller class. It gets the program started
 * @author Thomas Zangari
 * @version 10/02/2013
 */
public class Controller
{
    // instance variables - replace the example below with your own
    

    /**
     * Constructor for objects of class geometryTutor
     */
    public static void main(String[] args)
    {
        ItalianView view = new ItalianView();
        view.start();
        
    }

 }
