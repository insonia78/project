
/**
 * LAb 3: Geometry Tutor: Thomas Zangari
 * This class is the GeometryMaster. Its job is to solve the problems.
 * @author Thomas Zangari 
 * @version 
 */
public class ItalianMaster
{
    // instance variables - replace the example below with your own
    private String answer;
    

    
    public ItalianMaster()
    {
      answer ="";
    }

    public String computerGoodMorning()
    {
         answer = "Buon Giorno.";
        return answer;
    }
    public String computerGoodNight()
    {
        return answer = "Buona Notte.";
    }
    public String computerHelloHaYDoing ()
    {
        return  answer = "Ciao! how are you doing?";
    }
    
}
