
_upButton = new UpButton(350, 10, _cursor);
      _rightButton = new RightButton(670, 220, _cursor);
      _leftButton = new LeftButton(10, 220, _cursor);
      _downButton = new DownButton(350, 440, _cursor);
      _rightCornerButton = new RightCornerButton(670,10,_cursor);
      _leftCornerButton = new LeftCornerButton(10,10,_cursor);
      _rightDownCornerButton = new RightDownCornerButton(670, 440, _cursor);
      _leftDownCornerButton = new LeftDownCornerButton(10, 440, _cursor);