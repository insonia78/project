DELETE FROM table_video;
INSERT INTO table_video VALUES (1,'Avatar','sci-fi',170,'Sam Worthington,Zoe Saldana,Stephen Lang,Michelle Rodriguez,Sigourney Weaver','James Cameron');
INSERT INTO table_video VALUES (2,'Titanic','Historical',170,'Leonardo DiCaprio,Kate Winslet,Billy Zane,Kathy Bates,Frances Fisher,Bernard Hill','James Cameron');
INSERT INTO table_video VALUES (3,'The Avengers','sci-fi',170,'Robert Downey Jr.,Chris Evans,Mark Ruffalo,Chris Hemsworth,Scarlett Johansson,Jeremy Renner','Joss Whedon');
INSERT INTO table_video VALUES (4,'Harry Potter and the Deathly Hallows – Part 2 ','sci-fi',150,'Daniel Radcliffe,Rupert Grint,Emma Watson','David Yates');
INSERT INTO table_video VALUES (5,'Frozen','Cartoon',180,'Daniel Radcliffe,Rupert Grint,Emma Watson','Chris Buck');
INSERT INTO table_video VALUES (6,'Iron Man 3 ','sci-fi',150,'Robert Downey Jr.,Gwyneth Paltrow,Don Cheadle,Guy Pearce','Shane Black');
INSERT INTO table_video VALUES (7,'Transformers: Dark of the Moon ','sci-fi',180,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Michael Bay');
INSERT INTO table_video VALUES (8,'The Lord of the Rings: The Return of the King','fantasy',190,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (9,'Skyfall','sci-fi',140,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (10,'Transformers: Age of Extinction','sci-fi',190,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (11,'The Dark Knight Rises','Adventure',170,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (12,'Pirates of the Caribbean: Dead Man s Chest','fantasy',190,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (13,'Toy Story 3','fantasy',130,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (14,'Pirates of the Caribbean: On Stranger Tides','fantasy',170,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (15,'Jurassic Park','sci-fi',170,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (16,'Star Wars Episode I: The Phantom Menace','sci-fi',170,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (17,'Alice in Wonderland','fantasy',170,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (18,'The Hobbit: The Battle of the Five Armies','fantasy',190,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (19,'Harry Potter and the Order of the Phoenix','fantasy',160,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
INSERT INTO table_video VALUES (20,'Finding Nemo','fantasy',190,'Shia LaBeouf,Josh Duhamel,John Turturro,Tyrese Gibson','Peter Jackson');
	

														

