SELECT name,sex FROM student 
WHERE name LIKE '%a%'
ORDER BY name DESC limit 6;
 