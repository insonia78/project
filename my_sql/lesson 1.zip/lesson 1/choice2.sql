Select score,student_id from score
where score > 80
ORDER By student_id asc limit 5;
