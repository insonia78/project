INSERT INTO member (last_name,first_name)
VALUES('Zangari','Thomas');
