INSERT INTO president (last_name,first_name,city,state,birth)
VALUES('Obama','Barack', 'Honolulu', 'HA', '1961-08-04');
