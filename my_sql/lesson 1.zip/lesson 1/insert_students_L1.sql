INSERT INTO student VALUES('Thomas','M',NULL);
INSERT INTO grade_event VALUES('2013-01-14','Q',NULL);
INSERT INTO student
VALUES('Francis','F',NULL),('Xavier','M',NULL);
