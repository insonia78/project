SELECT * FROM
mysql.user;