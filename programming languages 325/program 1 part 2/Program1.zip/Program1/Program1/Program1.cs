﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public class Program1
    {
        char[] chart;
        public Program1()
        {
            String[] input = {"0x012efabd"," 0x1231324 sdf ","1234567","12 34 32","0x","   1", " abc","0","x","qqq qqq qqq "," qqq q qq ","qqqqq",
                               "0101010101101","01234567","01b2322334","01234567L"," 12 12 123","23345601"};
            bool Ok = false;
            
            
    
           foreach(String strings in input) 
           { 
               
              Ok = checkForSpaces(strings);
              if (Ok == true)
              {

                   
                 
                  

                  
                  if (Convert.ToInt32(chart[0]) >= 48 && Convert.ToInt32(chart[0]) <= 57)
                  {
                      try
                      {
                         if (chart[1] == 'x')
                         {
                            CheckForHexadecimal(chart, strings);
                         }
                      }
                      catch(IndexOutOfRangeException e)
                      {
                          CheckForOctalorForBinary(chart, strings);
                      }

                  }
                  else
                  {
                      Console.WriteLine("is {0} to be check as a string (y: n) ?", strings);
                      char answer = Convert.ToChar(Console.ReadLine());
                      if (answer == 'y' || answer == 'Y')
                      {
                          checkString(strings);
                      }
                      else
                      {
                          CheckForHexadecimal(chart,strings);
                      }
                  }
              }
              else
              {
                  Console.WriteLine("The Value '{0}' has an invalid Format", strings);

              }

           }             
                   
            Console.Read();
        }// end construcot
        public void CheckForOctalorForBinary(char[]chart,String strings)
        {
            bool check = true;
            for (int i = 0; i < chart.Length && check == true; i++)
            {
                if (chart[i] == '0')
                {
                    
                }
                else if (chart[i] == '1')
                {
                }
                else
                {
                    check = false;
                }
            }
            if (check == true)
            {
                Console.WriteLine("The string {0} is a valid Binary", strings);
            }
            else
            {
                check = false;
                for (int i = 0; i < chart.Length && check == false ; i++)
                {
                    if (chart[i] == '0')
                    {

                    }
                    else if (chart[i] == '1')
                    {
                    }
                    else if (chart[i] == '2')
                    {
                    }
                    else if (chart[i] == '3')
                    {
                    }
                    else if (chart[i] == '4')
                    {
                    }
                    else if (chart[i] == '5')
                    {
                    }
                    else if (chart[i] == '6')
                    {
                    }
                    else if (chart[i] == '7')
                    {
                    }
                    else
                    {
                        check = true;
                    }
                }
             
            }
            if (check == false)
            {
                Console.WriteLine("The string {0} is a valid Octal", strings);
            }
            else
            {
                check = false;
                for (int i = 0; i < chart.Length && check == false; i++)
                {
                    if (chart[chart.Length - 1] == 'L' || chart[chart.Length - 1] == 'l')
                    {
                        if (chart[i] == '0')
                        {

                        }
                        else if (chart[i] == '1')
                        {
                        }
                        else if (chart[i] == '2')
                        {
                        }
                        else if (chart[i] == '3')
                        {
                        }
                        else if (chart[i] == '4')
                        {
                        }
                        else if (chart[i] == '5')
                        {
                        }
                        else if (chart[i] == '6')
                        {
                        }
                        else if (chart[i] == '7')
                        {
                        }
                        else if (chart[i] == '8')
                        {

                        }
                        else if (chart[i] == '9')
                        {

                        }
                        else
                        {
                            check = true;
                        }
                    }
                    else
                    {
                        check = true;
                    }

                  }
            }
            if (check == false)
            {
                Console.WriteLine("The string {0} is a valid Long", strings);
            }
            
        }
        public bool checkForSpaces(String l)
        {

            bool ok = false;
            int spaces = 0,
                 leters = 0;
            char[] value = l.ToCharArray();

            int[] check = new int[value.Length];
            for (int i = 0; i < value.Length; i++)
            {
                if (value[i] == ' ')
                {
                    check[i] = 0;
                    spaces++;
                }
                else
                {
                    check[i] = 1;
                    leters++;
                }
            }
            if (check[0] == 0 && (value.Length - 1) == leters ) 
            {
                      chart = new char[value.Length - 1];
                      for (int i = 1; i < value.Length; i++)
                      {
                          chart[i - 1] = value[i];
                      }

                ok = true;
            }
            else if(check[value.Length - 1] == 0 && (value.Length - 1) == leters)
            {
                      chart = new char[value.Length - 1];
                      for (int i = value.Length; i > 0; i--)
                      {
                          chart[i - 1] = value[i];
                      }

                ok = true;
            }
            else if (check[0] == 0 && check[value.Length - 1] == 0 && (value.Length - 2) == leters)
            {
                      chart = new char[value.Length - 2];
                      for (int i = 1; i < value.Length - 1; i++)
                      {
                          chart[i - 1] = value[i];
                      }

                ok = true;
            }
            else if (value.Length == leters)
            {
                chart = new char[value.Length];
                for (int i = 0; i < value.Length; i++)
                {
                    chart[i] = value[i];
                }
                ok = true;
            }
            else
            {
                for (int i = 1; i < (value.Length - 1); i++)
                {
                    if (check[i] == 0 && check[i - 1] == 1 && check[i + 1] == 1)
                    {
                        ok = false;
                        break;
                    }
                    else
                    {
                        ok = true;
                    }
                }
                if(ok == true)
                {
                    chart = new char[leters];
                    int count = 0;
                    for (int i = 0; i < (value.Length); i++)
                    {
                        if (check[i] == 0)
                        {
                            count++;
                        }
                        else
                        {
                            chart[i - count] = value[i];                           
                        }
                    }
                }
            }


            return ok;
        }// end method
        public void checkString(String l)
        {
            char[] values = l.ToCharArray();
            Console.WriteLine("the String {0}", l);
            foreach (char character in values)
            {

                int value = Convert.ToInt32(character);

                string hex = String.Format("{0:X}", value);
                Console.WriteLine("Hexadecimal value of {0} is {1}", character, hex);
            }
        }// end method
        public bool CheckForHexadecimal(char[] chart,String l)
        {
            bool test = true;
            




            for (int i = 0; i < chart.Length; i++)
            {
                int v = chart[i];
                if (Convert.ToInt32(chart[i]) == 48 && i == 0 && chart.Length > 1)
                {

                }
                else if (Convert.ToInt32(chart[i]) == 120 && i == 1 && chart.Length > 2)
                {
                }
                else if (v >= 48 && v <= 57 && i > 1)
                {
                }
                else if (v >= 67 && v <= 70 && i > 1)
                {
                }
                else if (v >= 97 && v <= 102 && i > 1)
                {
                }
                else
                {
                    test = false;
                    break;
                }
              
            }
            Console.WriteLine("The String {0}", l);
            if (test == false)
            {

                Console.WriteLine("The letter {0} is false", l);

            }
            else
            {
                Console.WriteLine("The Hex {0} is true   ", l);
            }

            return test;
        }
    
     
        public static void Main(string[] args)
        {
            new Program1();
        }
     
    }
}
